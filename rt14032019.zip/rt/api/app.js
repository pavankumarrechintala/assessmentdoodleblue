var fs = require('fs')

var path = require('path')
var bodyparser = require('body-parser')
var express = require('express')
var promise = require('bluebird')
var app = express();

var options = { promiseLib: promise }
var total = require('pg-promise')(options)
var cs = 'postgres:postgres:root@localhost:5432/assessment'

var db = total(cs)

app.set('port', process.env.PORT || 4500)
app.all('*', function (req, res, next) {

    res.header("Access-Control-Allow-Origin", '*');

    res.header("Access-Control-Allow-Headers", "Cache-Control,Pragma, Origin, Authorization, Content-Type, X-Requested-With");

    res.header("Access-Control-Allow-Methods", "*");

    return next();
});

app.use(bodyparser.urlencoded({ limit: "100mb", extended: true }));
app.use(bodyparser.json({ limit: "100mb" }));

 app.use(express.static(path.join(__dirname,'Gallery')));
//  app.use(express.static(path.join(__dirname,'uimages')))

app.get('/', (req, res) => {
    res.send('DATBASE CONNECTED')
})



app.get('/getallusers/:user', (req, res, next) => {
    var user =req.params.user
 
    db.any('select * from login where username !=$1',[user]).then(
        (data) => {
            res.send(data)
        })
})

app.get('/logindetails/:i', (req, res, next) => {
    var i =req.params.i
    db.any('select * from login where username = $1',[i]).then(
        (data) => {
            res.send(data)
        })
})

app.post('/register/:latitude/:longitude', (req, res, next) => {
    console.log(req.body)
    console.log(req.params.latitude)
    console.log(req.params.longitude)
    var uname = req.body.username;
    var password = req.body.password;
    var place = req.body.place;
    var latitude = req.params.latitude;
    var longitude = req.params.longitude;
    var status = 'true'
    db.any('insert into login(username,password,place,latitude,longitude,userstatus ) values($1,$2,$3,$4,$5,$6)', [uname, password, place, latitude, longitude,status]).then((data) => {
        res.send(data)
    })
})

app.get('/login/:id/:pwd', (req, res, next) => {
    var pid = req.params.id
    var pw = req.params.pwd
    db.any('select * from login where username=$1 and password=$2', [pid, pw]).then(
        (data) => {
            res.send(data)

        })
})

app.put('/Inactive/:property_id/:status', (req, res) => {
   
    console.log('here')
    var localuser = req.params.property_id;
    var status = req.params.status;
    db.any("update login set userstatus=$1 where username=$2", [status, localuser]).then(data => {
        res.send({ 'message': 'updated' })
    })
})

app.get('/searchlongilatitudes/:user/:lat/:long', (req, res, next) => {
    var user =req.params.user
    var lat =req.params.lat
    var long =req.params.long
    db.any('select * from login where username !=$1 and latitude = $2 and longitude=$3 and userstatus= true',[user,lat,long]).then(
        (data) => {
            res.send(data)
        })
})

// app.post('/imageupload/:user', (req, res, next) => {
//     console.log(req.body)
//     var uname = req.params.user
//     var images = req.body.images
//     db.any('insert into images (username, images ) values($1,$2)', [uname,images]).then((data) => {
//         res.send(data)
//     })
// })
   
app.post('/imageupload/:uname', (req, res, next) => {// post Images..
   
   console.log(req.params.uname);
   var uname= req.params.uname;
    var images = req.body;
    console.log(images)
    
    
    

    var dir = "./Gallery/" + uname + "/"
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir)
        var imgPath = "./Gallery/" + uname + "/Images";
        fs.mkdirSync(imgPath);

    }

    var dt = new Date();
    fName = dt.getFullYear() + '_' + dt.getMonth() + '_' + dt.getDate() + '_' + dt.getHours() + '_' + dt.getMinutes() + '_' + dt.getMilliseconds() + 0 + ".png";
    fNameW = path.join(__dirname, 'Gallery/' + uname + '/Images/' + fName);
    fs.writeFile(fNameW, images, 'base64', (err) => {
        if (err)
            console.log('Unable to write ..');
        else
            console.log('Saved the image');

    })

    res.send({ message: "image uploaded" });
    
})


app.listen(app.get('port'), (err) => {
    if (err)
        console.log('server not strated ...')
    else
        console.log('server Started at  : http://localhost:4500')
})
