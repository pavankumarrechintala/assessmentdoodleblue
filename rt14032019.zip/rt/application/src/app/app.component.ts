import { Component, DoCheck } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements DoCheck {
  lgval: Observable<string>
  constructor(private rt:Router) {
  }

  private CheckLocalStore(): Observable<any> {
    return of(localStorage.getItem("username"));
}


logOutClick()
{
    localStorage.removeItem("username")
    this.rt.navigate(['login'])
}
  
  ngDoCheck() {
    this.CheckLocalStore().subscribe((data) => { this.lgval = data })
}
}
