


export class imageupload {
    image:any;
    uname:any;
}