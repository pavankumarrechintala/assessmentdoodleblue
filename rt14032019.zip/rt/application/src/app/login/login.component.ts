import { Component, OnInit } from '@angular/core';
import { TaskService } from '../service/task.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

constructor( private service: TaskService, private router: Router) { }

btnloginClick(u,p){
    // console.log(u+p)
this.service.loginserv(u,p).subscribe((data) => {

if (data.length > 0) {
localStorage.setItem("username",u)

this.router.navigate(['dashboard'])
}
else{
alert('invalid credintials')
}
})
}



  ngOnInit() {
  }

}
