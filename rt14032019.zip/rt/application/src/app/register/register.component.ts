import { Component, OnInit } from '@angular/core';
import { TaskService } from '../service/task.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  latitude: number;
  longitude: number;
  register: any = []
  constructor(private service: TaskService, private router: Router) {

  }

  btnclk(regfrm) {
    this.service.registerserv(regfrm, this.latitude, this.longitude).subscribe(data => {
      // location.reload()
      this.router.navigate(['/login']) 
    })
    


  }


  ngOnInit() {
    navigator.geolocation.getCurrentPosition((position) => {
      this.latitude = position.coords.latitude;
      this.longitude = position.coords.longitude;
    })

  }

}
