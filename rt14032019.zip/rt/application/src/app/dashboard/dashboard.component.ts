import { Component, OnInit } from '@angular/core';
import { TaskService } from '../service/task.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private service: TaskService) { }
  myProp1: any = 'Active'
  getlogin: any = []
  getlatlong:any=[]
  result:any;
  uploadFiles:any=[];
  property:any=[]
  imagearray:any=[];
  showbutton:any;
  allusers:any[]=[]



  handleChangee(event) {
    alert(JSON.stringify(event))
    var localuser = localStorage.getItem('username')
    this.service.Inactiveserv(event, localuser).subscribe(data => {

    })


  }

  latitudelongitudec(lat,long) {
    var user = localStorage.getItem('username')
    this.service.searchlongilatitudesserv(user,lat,long).subscribe(data => {
    alert(JSON.stringify(data))
      if(data != ''){
        this.getlatlong = data
        alert(JSON.stringify(this.getlatlong))

      }
      else{
        this.result = "User Not Found....."
      }
    })

  }


  
  onUpload(event) {     //upload Images

var user = localStorage.getItem('username')

    for (let file of event.files) {
      this.uploadFiles.push(file);
      
    }

console.log(this.uploadFiles)

    for (let i = 0; i < this.uploadFiles.length; i++) {
      this.property.image = this.uploadFiles[i];

      var reader = new FileReader();
      reader.readAsDataURL(this.uploadFiles[i]);   // read file as data url
      reader.onload = (ev: any) => {                 // called once readAsDataURL is completed
        this.property.image = ev.target.result;

        this.property.image = this.property.image.replace('data:image/gif;base64,', '')
        this.property.image = this.property.image.replace('data:image/jpeg;base64,', '')
        this.property.image = this.property.image.replace('data:image/png;base64,', '')
        this.imagearray.push(this.property.image);
        
    
      }
    }
    this.service.uploadfiles(this.imagearray, user).subscribe(data=>{
      
    })
    this.showbutton=true;
    alert('uploaded')
   
  }

  ngOnInit() {
    var localuser = localStorage.getItem('username')
    this.service.logindetails(localuser).subscribe(data => {
      this.getlogin = data[0]
      // alert(JSON.stringify(this.getlogin))
    })


var user= localStorage.getItem('username')
    this.service.getalluser(user).subscribe(data=>{
      this.allusers=data
      console.log(data);
    })
  

  }

}