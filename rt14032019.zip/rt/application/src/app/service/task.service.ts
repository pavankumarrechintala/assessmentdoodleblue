import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class TaskService {
  apiurl: string = "http://localhost:4500"
  constructor(private http: HttpClient) {
  }

  registerserv(regobj, latitude, longitude): Observable<any> {
    alert(JSON.stringify(regobj))
    const httpOptions = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    }
    return this.http.post(this.apiurl + '/register/' + latitude + '/' + longitude, JSON.stringify(regobj, latitude, longitude), httpOptions)

  }

  logindetails(i): Observable<any> {
    return this.http.get(this.apiurl + '/logindetails/'+ i, { responseType: 'json' })
  }

  searchlongilatitudesserv(user,lat,long): Observable<any> {
    return this.http.get(this.apiurl + '/searchlongilatitudes/'+ user + '/'+ lat+'/'+long, { responseType: 'json' })
  }


  loginserv(uid: any, pwd: any): Observable<any> {
    return this.http.get(this.apiurl + '/login/' + uid + '/' + pwd, { responseType: 'json' })
  }

  Inactiveserv(status: any, localuser:any): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.http.put(this.apiurl + '/Inactive/' + localuser + '/' + status, {}, httpOptions)
  }
  uploadfiles(image:any,user:any):Observable<any>{
    console.log(image)
    const httpOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.http.post(this.apiurl + '/imageupload/'+user ,JSON.stringify (image), httpOptions)
  }

  getalluser(user):Observable <any>{

return this.http.get(this.apiurl+'/getallusers'+'/'+user,{ responseType: 'json' })

  }
}
